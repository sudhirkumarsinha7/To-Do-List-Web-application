<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
    public function response($code,$request,$msg,$output=array()){
        $resp = array('status_code'=>$code, 'request_type'=>$request, 'status_msg'=>$msg, 'output'=>$output);
        echo json_encode($resp);
        return false;
    }
          
}
