<!doctype html>
<html>
    <head>
        <link rel='icon' href="<?php echo base_url('images/fav.png') ?>" type='image/png'>
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css') ?>">

        <script src="<?php echo base_url('assets/js/jquery-1.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
        <style>
            .bold{
                font-weight: bold;
            }
            .title{
                font-weight: bold;
            }
            .desc{
                font-size: 10px;
            }
            .height-limit-1{
                max-height: 300px;
                overflow-y: scroll;
            }
            .light{
                color:#999;
            }
            
            .pointer{
                cursor: pointer;
            }
        </style>
    </head>
    <body>
        <div class="container" ng-app="myApp" ng-controller="myCtrl">
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="text-center page-header">To Do Task Assignment</h4>
                </div>
                <!-- Modal -->
                <div id="myModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">{{model_title}}</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <input type="text" name="newTitle" placeholder="task title" class="form-control" ng-model="newTitle">
                                </div>
                                <div class="form-group">
                                    <textarea type="text" name="newDisc" class="form-control" rows="2" ng-model="newDesc"></textarea>
                                </div>                                
                                <div class="form-group">
                                    <button type="button" class="btn btn-success" ng-click="saveNewTask()" ng-if="isNew">SAVE</button>
                                    <button type="button" class="btn btn-success" ng-click="updateTask(this.update_id)" ng-if="isUpdate" update_id="{{update_id}}">UPDATE</button>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <span class="bold">Pending Task</span>
                            <button type="button" class="btn btn-success btn-xs pull-right" ng-click="showAddNewTaskwForm()">Add New Task</button>                                                           
                        </div>
                        <div class="panel-body height-limit-1">
                            <h3 ng-if="Ploading" class="text-center bold">Loading...</h3>
                            <div class="task" ng-repeat="row in pendingTask" id="task_{{row.seq_no}}">
                                <div class="col-xs-1">
                                    <input type="checkbox" ng-click="markDone($event, row.seq_no)">                                
                                </div>                      
                                <div class="col-xs-11">
                                    <span class="pull-right fa fa-trash pointer" ng-click="deleteTask($event, row.seq_no)"></span>
                                    <span class="pull-right fa fa-refresh pointer" ng-click="showEditForm($event, row.seq_no, row.tittle, row.discription)"></span>
                                    <span class="title">{{row.tittle}}</span><br>
                                    <span class="desc">{{row.discription}}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <span class="bold">Task Done</span>
                        </div>
                        <div class="panel-body height-limit-1">
                            <h3 ng-if="Dloading" class="text-center bold">Loading...</h3>
                            <div class="task" ng-repeat="r in doneTask" id="task_{{r.seq_no}}">
                                <div class="col-xs-1">
                                    <input type="checkbox" ng-click="undo($event, r.seq_no)" checked="true">    
                                </div>                      
                                <div class="col-xs-11">
                                    <span class="title light"><del>{{r.tittle}}</del></span><br>
                                    <span class="desc light"><del>{{r.discription}}</del></span>
                                </div>
                            </div>
                        </div>
                    </div>                   
                </div>                
            </div>
        </div>


        <script>
            //getPreventDefault();
            var base_url = 'http://localhost:8080/todo/index.php/Todo/';
            var app = angular.module('myApp', []);
            app.controller('myCtrl', function ($scope, $http) {
                $scope.Ploading = true;
                $scope.Dloading = true;
                $scope.init = function (event) {
                $http({
                    method: 'POST',
                            url: base_url + 'showAllTask',
                            data: $.param({
                            status: "pending"
                            }),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).success(function (data, status, headers, config) {
                    $scope.Ploading = false;
                    $scope.pendingTask = data.output;
                    //console.log(data.output);
                    }).error(function (data, status, headers, config) {
                    // handle error things
                });
                //loading task done
                $http({
                    method: 'POST',
                            url: base_url + 'showAllTask',
                            data: $.param({
                            status: "done"
                            }),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).success(function (data, status, headers, config) {
                    $scope.Dloading = false;
                    $scope.doneTask = data.output;
                    //console.log(data.output);
                    }).error(function (data, status, headers, config) {
                    // handle error things
                    });
                };
                $scope.init();               

                $scope.showAddNewTaskwForm = function(){                   
                   $scope.newTitle = "";
                   $scope.newDesc = "";
                   $scope.model_title = "Add New Task";
                   $scope.isNew = true;
                   $scope.isUpdate = false;
                   angular.element('#myModal').modal('show');
                };

                // save new task
                $scope.saveNewTask = function(){
                    var newTitle = $scope.newTitle;
                    var newDesc = $scope.newDesc;                                
                    $http({
                    method: 'POST',
                            url: base_url + 'addTask',
                            data: $.param({
                            title:newTitle,
                            discription:newDesc
                            }),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).success(function (data, status, headers, config) {                        
                        alert("new Task Added Successfully");
                        $scope.newTitle = "";
                        $scope.newDesc = "";
                        angular.element('#myModal').modal('hide');
                        $scope.init();
                    }).error(function (data, status, headers, config) {
                    // handle error things
                    });
                };

                //mark done
                $scope.markDone = function($event, id) {                    
                    var checkbox = $event.target;
                    $http({
                    method: 'POST',
                            url: base_url + 'markTaskDone',
                            data: $.param({
                            task_id:id                         
                            }),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).success(function (data, status, headers, config) {
                        $scope.init();
                        //alert("new Task Added Successfully");                                            
                    }).error(function (data, status, headers, config) {
                    // handle error things
                    });
                };
                
                //undo task 
                $scope.undo = function($event, id) {   
                    //console.log(id);return;
                    var checkbox = $event.target;
                    $http({
                    method: 'POST',
                            url: base_url + 'undoMarkDone',
                            data: $.param({
                            task_id:id                         
                            }),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).success(function (data, status, headers, config) {
                        $scope.init();
                        //alert("new Task Added Successfully");                                            
                    }).error(function (data, status, headers, config) {
                    // handle error things
                    });
                };
                
                //delete task 
                $scope.deleteTask = function($event, id) {                      
                    $http({
                    method: 'POST',
                            url: base_url + 'deleteTask',
                            data: $.param({
                            task_id:id                         
                            }),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).success(function (data, status, headers, config) {
                        $scope.init();
                        //alert("new Task Added Successfully");                                            
                    }).error(function (data, status, headers, config) {
                    // handle error things
                    });
                };
                
               $scope.showEditForm = function($event, id, t, d){                   
                   $scope.newTitle = t;
                   $scope.newDesc = d;
                   $scope.model_title = "Update Task";
                   $scope.isNew = false;
                   $scope.isUpdate = true;
                   $scope.update_id = id;
                   angular.element('#myModal').modal('show');
               };
                
                //update task 
                $scope.updateTask = function(id) {   
                    //console.log(id); return;
                    $http({
                    method: 'POST',
                            url: base_url + 'editTask',
                            data: $.param({
                            task_id:id,
                            title:$scope.newTitle,
                            discription:$scope.newDesc
                            }),
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).success(function (data, status, headers, config) {
                        alert("Task updated Successfully");
                        $scope.newTitle = "";
                        $scope.newDesc = "";
                        angular.element('#myModal').modal('hide');
                        $scope.init();
                        //alert("new Task Added Successfully");                                            
                    }).error(function (data, status, headers, config) {
                    // handle error things
                    });
                };
            });
        </script>
    </body>
</html>